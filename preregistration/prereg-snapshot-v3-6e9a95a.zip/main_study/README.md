# Contextual Alignment Study — main study

Fresh, pinned, multi-model campaign for the v0.4 design (see
`../study_design-2.md`). The old pilots (GPT/Claude/Grok, abortion+guns,
free-text only) now live in `../old/` and are kept as pilot + a reusable
transcript corpus — not part of the confirmatory dataset.

## Construct (three axes, read against topic targets)
- **Position** — resting stance with no user cue.
- **Mirroring** — shift toward the user's signaled ideology.
- **Steadfastness** — whether it holds under the escalating-pressure ladder.

## Models (six developers, §4a) — PINNED 2026-07-02
Rule: most current GA model per developer at the pin date (Anthropic:
Opus 4.8 rather than Fable 5 — Fable 5 access won't persist through the
collection window).
`claude` = Claude Opus 4.8 · `gpt` = GPT-5.5 (2026-04-23) · `grok` = Grok 4.3
· `gemma` = Gemma 4 31B IT · `mistral` = Mistral Small 3.2 24B (2506; prereg
Amendment A1 — the design's ~24B class) · `deepseek` = V4 Flash (non-thinking
= the deepseek-chat successor). Open models all served by DeepInfra from open
weights; closed models on native APIs. Opus 4.8 + GPT-5.5 reject sampling
params (banned via param_overrides; they run provider defaults); re-verify
SKUs if collection slips weeks past the pin date.

## Layout
```
config.py            model registry + TOPICS registry (cue levels & numeric
                     coding, target types, scorer paths) + pinned GEN_PARAMS
model_client.py      unified chat() — Anthropic native + OpenAI-compatible for
                     the rest; retries transient errors; resolve_params()
00_smoke_test.py     ping all models; run this first
01_collect.py        naturalistic protocol (exp2 replication) -> data/raw/
                     validates persona files against TOPICS before any call;
                     resumes (skips existing cells); saves *.FAILED.json on
                     error; writes provenance into records + .meta.json  [ready]
02_build.py          transcripts -> data/processed/long.csv (one row per turn,
                     cue coding, scoring plan, profiling parse) + completeness
                     report                                            [ready]
03_score.py          refusal classifier + per-topic stance scoring by
                     config.JUDGE_MODELS (>=2 judges, consensus + disagreement
                     flags, self-judge marks, resumable scores.jsonl)  [ready]
04_analyze.py        three-axis signatures: position/refusal, mirroring
                     (+ asymmetry + §5 refusal-imputation bounds),
                     refusal-as-mirroring, steadfastness (+ cue x pressure),
                     anchored deviation, spillover, profiling check    [ready]
prompts/
  personas/          conversation script per topic (see personas/README.md);
                     abortion verbatim from pilot; drafts dose-matched to its
                     7-turn arc; vaccines drafted as optional (§8.5)
  scoring/           refusal_classifier.txt + per-topic stance scales:
                     stance_{abortion,climate,nazism,catalan,control,guns,vaccines}.txt
                     (stance_scorer.txt = deprecated generic scale)
  stance_statements/ DEPRECATED — structured battery dropped in v0.4 (see §4e)
data/raw/  data/processed/  results/
```

## Measure (v0.4)
Naturalistic free-text conversation (the pilot exp2 design), replicated across
the six models and the topic battery. The outcome is the free-text answer;
refusal is labeled and stance is scored at Stage 3 on the topic's own scale
(direction always matches the cue coding, so mirroring slopes are comparable).
No survey/structured turns.

## Setup
```bash
pip install -r requirements.txt
export OPENAI_API_KEY=...      ANTHROPIC_API_KEY=...   XAI_API_KEY=...
export OPENROUTER_API_KEY=...  DEEPSEEK_API_KEY=...     # open models + deepseek
python 00_smoke_test.py
python 01_collect.py --dry-run --models all --topics core   # validate + plan
```
Keys are read from env vars only — never hardcoded (unlike the old pilot
scripts; those exposed keys should be **rotated**, and the project should be
**git-init'ed** once `old/` is scrubbed).

## Pipeline
```bash
python 01_collect.py --models all --topics core --runs 3   # -> data/raw/
python 02_build.py                                         # -> data/processed/long.csv
python 03_score.py --limit 40                              # pilot-score first, then full
python 04_analyze.py                                       # -> results/signatures.csv
```
Every stage resumes/rebuilds safely. The whole chain is end-to-end tested on
synthetic transcripts with planted effects (mirroring/steadfastness slopes,
selective refusal, bounds, spillover, profiling) — all recovered exactly.

## Status
**Preregistered:** frozen instrument + analysis plan deposited at Zenodo.
Binding: v2 — DOI [10.5281/zenodo.21133710](https://doi.org/10.5281/zenodo.21133710)
(restricted; snapshot = git commit `3f8912c`, 2026-07-02, incl. pre-data
Amendment A1). Superseded v1: DOI
[10.5281/zenodo.21133390](https://doi.org/10.5281/zenodo.21133390). See
`preregistration.md`.

Ready now: the full Stage 0–4 pipeline (registries, client, smoke test,
collection, build, scoring, analysis), all six persona scripts (abortion
verbatim; climate, nazism, catalan, control dose-matched v2 drafts; vaccines
optional draft), refusal classifier + seven per-topic stance scorers.

Remaining:
1. Final wording review of the five non-abortion persona scripts.
2. Decide vaccines in/out of the battery (§8.5) — flip `status` in `config.TOPICS`.
3. Export keys -> `python 00_smoke_test.py` (verifies the six pinned SKUs
   resolve; DeepSeek: confirm v4-flash defaults to non-thinking mode).
4. After scoring: human-code a validation subset, report judge agreement (§4e);
   pre-register the contested-topic neutral range (config TODO(preregister)).
5. Later: paraphrase variants + temperature-sweep CLI (§4g) — the pooled mixed
   model waits on them; pin HF revision hashes at vLLM setup (open sub-study).
6. Hygiene: rotate the exposed keys in `../old/`, then git-init the project.
