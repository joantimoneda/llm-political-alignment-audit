"""
STAGE 4 — Analyze (study §5): per model x topic three-axis signatures.

From data/processed/scored.csv (Stage 3) + long.csv (Stage 2):

  POSITION    — resting stance with no user cue: mean stance on the COLD cell
                probe (step 0), genuine answers only, reported next to the
                cold refusal rate (a heavy refuser's "position" is that rate,
                never a forced number).
  MIRRORING   — OLS stance ~ cue_code + pressure_step on genuine answers
                (cold excluded; cue coding from config.TOPICS — positive =
                the pole scoring high on that topic's scale, so slope > 0
                always means "moved toward the user"). Plus: probe-only
                slope (robustness), liberal/conservative-side asymmetry, and
                the §5 selection-bias BOUNDS: worst-case re-fits with refused
                answers imputed at the scale extremes in the direction that
                maximally raises/lowers the slope.
  REFUSAL-AS-MIRRORING — LPM refused ~ cue_code: does WHETHER it answers
                depend on who is asking (§2 identifiability caveat).
  TRANSMITTED STANCE — pre-registered SECONDARY estimand: the reader-effect
                reading, where a refusal transmits neutrality to the user —
                REFUSES imputed at the scale midpoint (5), then the same
                position/mirroring/steadfastness quantities recomputed
                (*_transmitted columns; = the pilot's original coding, and
                the midpoint of the imputation bounds above). Divergence
                between the structural and transmitted readings is itself a
                finding: neutrality-as-transmitted can mask movement in the
                refusal channel.
  STEADFASTNESS — OLS stance ~ pressure_step + C(cue_level): movement per
                escalation step; plus the cue x pressure interaction (does
                the cue gap widen under pressure — the pilot's Grok effect).
  ANCHORED    — deviation from config.TOPICS[...]["target"] (point targets
                for empirical/settled topics, range for contested, none for
                control): cold deviation + drift at the extreme cues.
  SPILLOVER   — abortion sessions only: guns stance ~ abortion cue_code
                (halo), attached to the abortion row.
  PROFILING CHECK — OLS profiled_user ~ cue_code from the long table: did
                the model read the cue as intended? (Directional check only
                for climate/vaccines/nazism, where the profiling axis is
                conservative<->liberal but the cue axis is not.)

Cue-coding caveats (config.TOPICS notes): nazism has two cue levels -> its
"mirroring" is a two-point contrast, not a slope (the OLS coefficient IS that
contrast); control is 3-point. The pooled mixed model (topic/item random
effects, target-type moderation) is NOT fit here: with one item per topic it
is degenerate until paraphrase variants exist (§4g) — build it with them.

Outputs: results/signatures.csv (one row per model x topic),
results/cell_means.csv (means for plotting), printed per-topic report.

    python 04_analyze.py
    python 04_analyze.py --scored PATH --long PATH --out DIR
"""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

from config import TOPICS

HERE = Path(__file__).parent
PROC = HERE / "data" / "processed"
RESULTS = HERE / "results"


# --------------------------------------------------------------------------
# Small-sample-safe OLS helper
# --------------------------------------------------------------------------
def ols_coef(df, formula, coef, min_n=3):
    """Return (est, se, p, n) for one coefficient; NaNs when unidentifiable."""
    nan = (float("nan"),) * 3
    tokens = [t.strip().replace("C(", "").replace(")", "")
              for t in formula.replace("~", "+").replace("*", "+").split("+")]
    d = df.dropna(subset=[c for c in tokens if c in df.columns])
    try:
        xvar = coef.split(":")[0]
        if len(d) < min_n or (xvar in d and d[xvar].nunique() < 2):
            return (*nan, len(d))
        fit = smf.ols(formula, data=d).fit(cov_type="HC1")
        if coef not in fit.params.index:
            return (*nan, int(fit.nobs))
        return (float(fit.params[coef]), float(fit.bse[coef]),
                float(fit.pvalues[coef]), int(fit.nobs))
    except Exception:
        return (*nan, len(d))


def target_deviation(stance, target):
    if target is None or pd.isna(stance):
        return float("nan")
    if target["kind"] == "point":
        return abs(stance - target["value"])
    return max(0.0, target["lo"] - stance, stance - target["hi"])


# --------------------------------------------------------------------------
# Per model x topic signature
# --------------------------------------------------------------------------
def signature(d, long_d, topic):
    """d = scored rows for one model x topic (main turns only, no spillover)."""
    out = {}
    labeled = d[d.label_consensus.isin(["TAKES_POSITION", "REFUSES", "ASSERTS_DEFAULT"])].copy()
    labeled["refused"] = (labeled.label_consensus == "REFUSES").astype(float)
    genuine = labeled[labeled.genuine & labeled.stance_mean.notna()].copy()
    cold_probe = labeled[labeled.cue_code.isna() & (labeled.pressure_step == 0)]
    cold_probe_gen = cold_probe[cold_probe.genuine & cold_probe.stance_mean.notna()]

    out["n_answers"] = len(d)
    out["n_labeled"] = len(labeled)
    out["disputed_rate"] = float((d.label_consensus == "DISPUTED").mean()) if len(d) else np.nan
    out["asserts_default_rate"] = float((labeled.label_consensus == "ASSERTS_DEFAULT").mean()) if len(labeled) else np.nan

    # position (cold probe) + refusal
    out["position_cold"] = float(cold_probe_gen.stance_mean.mean()) if len(cold_probe_gen) else np.nan
    out["refusal_cold"] = float(cold_probe.refused.mean()) if len(cold_probe) else np.nan
    out["refusal_rate"] = float(labeled.refused.mean()) if len(labeled) else np.nan

    # mirroring (cued cells only)
    cued = genuine[genuine.cue_code.notna()]
    out["mirroring"], out["mirroring_se"], out["mirroring_p"], out["mirroring_n"] = \
        ols_coef(cued, "stance_mean ~ cue_code + pressure_step", "cue_code")
    out["mirroring_probe"], *_rest = ols_coef(
        cued[cued.pressure_step == 0], "stance_mean ~ cue_code", "cue_code")
    out["mirroring_neg_side"], *_ = ols_coef(
        cued[cued.cue_code <= 0], "stance_mean ~ cue_code + pressure_step", "cue_code")
    out["mirroring_pos_side"], *_ = ols_coef(
        cued[cued.cue_code >= 0], "stance_mean ~ cue_code + pressure_step", "cue_code")

    # selection-bias bounds (§5): impute refused answers at scale extremes
    lab_cued = labeled[labeled.cue_code.notna()].copy()
    scored_or_refused = lab_cued[lab_cued.genuine | (lab_cued.refused == 1)].copy()

    def bound(direction):
        # Push each refused answer to the scale extreme that moves the slope
        # up ("max") or down ("min"): 5 + sign*sign(cue)*5 -> 0/5/10.
        sign = 1.0 if direction == "max" else -1.0
        b = scored_or_refused.copy()
        b["stance_b"] = b.stance_mean
        ref = b.refused == 1
        b.loc[ref, "stance_b"] = 5.0 + sign * np.sign(b.loc[ref, "cue_code"]) * 5.0
        est, *_ = ols_coef(b, "stance_b ~ cue_code + pressure_step", "cue_code")
        return est

    out["mirroring_lo"] = bound("min")
    out["mirroring_hi"] = bound("max")

    # refusal-as-mirroring (LPM)
    out["refusal_mirroring"], out["refusal_mirroring_se"], out["refusal_mirroring_p"], _ = \
        ols_coef(lab_cued, "refused ~ cue_code", "cue_code")

    # transmitted-stance reading (secondary estimand, §5): a refusal transmits
    # neutrality to the reader -> REFUSES imputed at 5, same regressions.
    trans = labeled[labeled.genuine | (labeled.refused == 1)].copy()
    trans["stance_t"] = trans.stance_mean.where(trans.refused != 1, 5.0)
    cold_t = trans[trans.cue_code.isna() & (trans.pressure_step == 0)]
    out["position_cold_transmitted"] = float(cold_t.stance_t.mean()) if len(cold_t) else np.nan
    out["mirroring_transmitted"], out["mirroring_transmitted_se"], \
        out["mirroring_transmitted_p"], _ = ols_coef(
            trans[trans.cue_code.notna()], "stance_t ~ cue_code + pressure_step", "cue_code")
    out["steadfastness_transmitted"], _, out["steadfastness_transmitted_p"], _ = \
        ols_coef(trans, "stance_t ~ pressure_step + C(cue_level)", "pressure_step")

    # steadfastness
    out["steadfastness"], out["steadfastness_se"], out["steadfastness_p"], _ = \
        ols_coef(genuine, "stance_mean ~ pressure_step + C(cue_level)", "pressure_step")
    out["pressure_x_cue"], _, out["pressure_x_cue_p"], _ = \
        ols_coef(cued, "stance_mean ~ cue_code * pressure_step", "cue_code:pressure_step")

    # anchored reading
    target = TOPICS[topic]["target"]
    out["dev_cold"] = target_deviation(out["position_cold"], target)
    if target is not None and len(genuine):
        ext = genuine[genuine.cue_code.abs() == genuine.cue_code.abs().max()]
        devs = ext.stance_mean.map(lambda s: target_deviation(s, target))
        out["anchor_drift"] = float(devs.mean() - out["dev_cold"]) if len(devs) and not pd.isna(out["dev_cold"]) else np.nan
    else:
        out["anchor_drift"] = np.nan

    # profiling manipulation check (from long table)
    prof = long_d[(long_d.turn_type == "profiling") & long_d.profiled_user.notna()
                  & long_d.cue_code.notna()]
    out["profiling_check"], _, out["profiling_check_p"], out["profiling_n"] = \
        ols_coef(prof, "profiled_user ~ cue_code", "cue_code")
    return out


def spillover_signature(sp, out):
    """sp = scored spillover rows (e.g. guns) for one model; attach to out."""
    labeled = sp[sp.label_consensus.isin(["TAKES_POSITION", "REFUSES", "ASSERTS_DEFAULT"])].copy()
    genuine = labeled[labeled.genuine & labeled.stance_mean.notna()]
    cued = genuine[genuine.cue_code.notna()]
    out["spill_slope"], out["spill_se"], out["spill_p"], out["spill_n"] = \
        ols_coef(cued, "stance_mean ~ cue_code + pressure_step", "cue_code")
    out["spill_refusal"] = float((labeled.label_consensus == "REFUSES").mean()) if len(labeled) else np.nan
    return out


# --------------------------------------------------------------------------
# Driver
# --------------------------------------------------------------------------
def analyze(scored_path, long_path, out_dir):
    df = pd.read_csv(scored_path)
    long_df = pd.read_csv(long_path)
    if df.empty:
        raise SystemExit("scored table is empty — run 03_score.py first")

    main = df[df.scoring_topic == df.topic]
    spill = df[df.scoring_topic != df.topic]

    rows = []
    for (model, topic), d in main.groupby(["model", "topic"]):
        ld = long_df[(long_df.model == model) & (long_df.topic == topic)]
        out = {"model": model, "topic": topic,
               "target_type": TOPICS[topic]["target_type"]}
        out.update(signature(d, ld, topic))
        sp = spill[(spill.model == model) & (spill.topic == topic)]
        if len(sp):
            out["spill_topic"] = sp.scoring_topic.iloc[0]
            out = spillover_signature(sp, out)
        rows.append(out)
    sig = pd.DataFrame(rows).sort_values(["topic", "model"]).reset_index(drop=True)

    # per-cell means for plotting
    cm = (df.assign(refused=(df.label_consensus == "REFUSES").astype(float))
            .groupby(["model", "topic", "scoring_topic", "cue_level", "cue_code",
                      "pressure_step"], dropna=False)
            .agg(stance=("stance_mean", "mean"), refusal=("refused", "mean"),
                 n=("stance_mean", "size"))
            .reset_index())

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    sig_path, cm_path = out_dir / "signatures.csv", out_dir / "cell_means.csv"
    sig.to_csv(sig_path, index=False)
    cm.to_csv(cm_path, index=False)
    print(f"wrote {sig_path}  ({len(sig)} model x topic signatures)")
    print(f"wrote {cm_path}")

    # printed report (structural reading first; transmitted = secondary estimand)
    show = ["model", "position_cold", "refusal_cold", "mirroring", "mirroring_lo",
            "mirroring_hi", "refusal_mirroring", "steadfastness", "dev_cold", "anchor_drift",
            "position_cold_transmitted", "mirroring_transmitted"]
    for topic, g in sig.groupby("topic"):
        print(f"\n=== {topic}  ({TOPICS[topic]['target_type']}; "
              f"scale: {TOPICS[topic]['scale']}) ===")
        print(g[show].round(2).to_string(index=False))
        if topic in ("nazism", "control"):
            print("    NB: cue is categorical here — 'mirroring' is a contrast, not a slope.")
    ab = sig[sig.topic == "abortion"]
    if "spill_slope" in sig.columns and len(ab):
        print("\n=== spillover (abortion cue -> guns probe; sensitized halo, §4c) ===")
        print(ab[["model", "spill_slope", "spill_p", "spill_refusal"]].round(2).to_string(index=False))
    print("\nNOT fit here: pooled mixed model with topic/item random effects — "
          "degenerate with one item per topic until paraphrase variants exist (§4g).")
    return sig


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Stage 4 — three-axis signatures per model x topic.")
    ap.add_argument("--scored", default=str(PROC / "scored.csv"))
    ap.add_argument("--long", default=str(PROC / "long.csv"))
    ap.add_argument("--out", default=str(RESULTS))
    a = ap.parse_args()
    analyze(a.scored, a.long, a.out)
