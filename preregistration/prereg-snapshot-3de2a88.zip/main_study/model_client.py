"""
Unified chat client across all six developers in the study.

One native path for Anthropic; everything else (OpenAI, xAI, DeepSeek, and the
open-weight models via OpenRouter or a local vLLM server) speaks the
OpenAI-compatible Chat Completions API. That keeps collection code identical
across five of the six providers.

    from model_client import chat
    reply = chat("grok", [{"role": "user", "content": "hi"}])

Generation params resolve as: config.GEN_PARAMS < MODELS[key]["param_overrides"]
< caller kwargs, where a None value removes the key (see resolve_params).
The resolved dict is what run_session records as provenance. Transient API
errors (429 / 5xx / network) are retried with exponential backoff.

Keys come from environment variables named in config.MODELS[...]["api_key_env"].
Never hardcode a key.
"""
import os
import time

from config import MODELS, GEN_PARAMS

MAX_ATTEMPTS = 5
BACKOFF_S = 2.0                       # doubles each retry: 2, 4, 8, 16
RETRYABLE_CODES = {408, 409, 429, 500, 502, 503, 504}


def resolve_params(model_key, **kw):
    """Effective generation params for one call (also recorded as provenance).

    Merge order: GEN_PARAMS < param_overrides < caller kwargs. A None value in
    param_overrides is a BAN — the key is stripped even if a caller passes it
    (the pinned claude/gpt SKUs reject explicit sampling params with a 400, so
    a ban is always safer than forwarding).
    """
    overrides = MODELS[model_key].get("param_overrides", {})
    banned = {k for k, v in overrides.items() if v is None}
    p = dict(GEN_PARAMS)
    p.update({k: v for k, v in overrides.items() if v is not None})
    p.update(kw)
    return {k: v for k, v in p.items() if v is not None and k not in banned}


def _require_key(model_key):
    env = MODELS[model_key]["api_key_env"]
    key = os.environ.get(env)
    if not key:
        raise RuntimeError(
            f"Missing env var {env} for model '{model_key}'. "
            f"Set it (e.g. `export {env}=...`) before running."
        )
    return key


def _retryable(exc):
    # No status_code = network error / timeout -> retry. Auth and bad-request
    # style errors carry 4xx codes outside the set and fail immediately.
    code = getattr(exc, "status_code", None)
    return code is None or code in RETRYABLE_CODES


def _chat_openai(model_key, messages, params):
    from openai import OpenAI
    m = MODELS[model_key]
    client = OpenAI(api_key=_require_key(model_key), base_url=m.get("base_url"))
    resp = client.chat.completions.create(model=m["model_id"], messages=messages, **params)
    return resp.choices[0].message.content


def _chat_anthropic(model_key, messages, params):
    import anthropic
    m = MODELS[model_key]
    client = anthropic.Anthropic(api_key=_require_key(model_key))
    # Anthropic takes `system` separately and requires max_tokens.
    system = next((x["content"] for x in messages if x["role"] == "system"), None)
    convo = [x for x in messages if x["role"] != "system"]
    params = dict(params)
    max_tokens = params.pop("max_tokens", 1024)
    resp = client.messages.create(
        model=m["model_id"],
        system=system if system is not None else anthropic.NOT_GIVEN,
        max_tokens=max_tokens,
        messages=convo,
        **params,
    )
    # Current Claude models emit thinking blocks before the text (always-on
    # for Fable 5) — join the text blocks; never index content[0] blindly.
    return "".join(b.text for b in resp.content if b.type == "text")


def chat(model_key, messages, **kw):
    """Send OpenAI-style `messages` to `model_key`; return the reply text.

    kwargs override GEN_PARAMS / param_overrides (see resolve_params). Note
    providers differ on some param names — gpt-5.x want max_completion_tokens,
    handled via param_overrides in config; the smoke test surfaces the rest.
    """
    _require_key(model_key)                       # fail fast; never retried
    params = resolve_params(model_key, **kw)
    fn = _chat_anthropic if MODELS[model_key]["provider"] == "anthropic" else _chat_openai
    for attempt in range(MAX_ATTEMPTS):
        try:
            return fn(model_key, messages, params)
        except Exception as e:
            if attempt == MAX_ATTEMPTS - 1 or not _retryable(e):
                raise
            time.sleep(BACKOFF_S * (2 ** attempt))
