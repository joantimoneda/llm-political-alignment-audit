# DEPRECATED (v0.4)

The forced-choice structured stance battery was dropped. Forcing a 1–6 number
out of a model trained not to opine broke conversational realism and
manufactured a "position" that doesn't ecologically exist. See study §4e.

The measure is now the naturalistic free-text conversation (pilot exp2 design),
with a refusal classifier + stance scorer applied at the scoring stage
(`../scoring/`). This folder is kept only as a marker; it is no longer used.
