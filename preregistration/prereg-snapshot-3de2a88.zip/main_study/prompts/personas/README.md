# Persona / user-cue prompts (study §4d)

The protocol is data: one file per topic, sections in `[brackets]`, one user
turn per non-blank line, `#` starts a comment line. Each topic must be
registered in `config.TOPICS` — `01_collect.py` cross-validates file against
registry before any API call (cue sections must match `cue_code` exactly; a
missing section is a hard error, never a silent empty cue).

Sections:

- `[cue <level>]` — one block per cue level. `[cue cold]` must exist and stay
  **empty**: the no-persona cold-ask baseline (claiming to be *undecided* is
  itself a cue — that's what the `neutral` level is for).
- `[probe]` — exactly one line: the direct question.
- `[pressure]` — the escalation ladder (steadfastness), one step per line.
- `[profiling]` — the 0–10 "where do I fall" turns. Omit for control; must
  match `config.TOPICS[...]["profiling"]`.
- `[spillover <topic>]` — optional: probe + pressure for an *unmentioned*
  second topic (abortion → guns), scored with its own scale.

Authoring rules:

- **Dose-match the abortion arc** (verbatim pilot — never edit `abortion.txt`):
  7 user turns per cue = greeting, frame, three substantive turns, a summary
  position ("Thanks for all your thoughts. …"), a close. The `neutral` cue
  includes the pilot's mid-cue "What do you think?". Without dose-matching,
  cross-topic mirroring magnitudes confound cue strength with cue length.
- The cue axis is topic-specific (ideology / evidence stance / sympathy /
  union↔independence). Code its direction in `config.TOPICS[...]["cue_code"]`
  with **positive = the pole that scores high (10)** on the topic's stance
  scale, so a positive mirroring slope always means "moved toward the user".
- Nazism deliberately has two cue levels (neutral, sympathetic) → its
  mirroring is a two-point contrast, not a slope.
- `vaccines.txt` is drafted but **optional** (`status: "optional"` in the
  registry; §8.5) — flip to `"core"` to include it in the battery.

Status: abortion = verbatim exp2; climate / nazism / catalan / control =
revised drafts (v2, dose-matched); vaccines = new draft. All non-abortion
scripts still need a final wording review before collection.
